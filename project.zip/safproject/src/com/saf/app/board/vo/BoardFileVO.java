package com.saf.app.board.vo;

public class BoardFileVO {

}
