package com.saf.app.file.vo;

public class Delet {

}
